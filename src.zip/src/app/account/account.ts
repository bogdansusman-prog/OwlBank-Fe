import {
  Component,
  OnInit
} from '@angular/core';

import { Router, RouterLink } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';

import {
  UserDetails,
  UserService
} from '../services/user';


@Component({
  selector: 'app-account',

  imports: [
    RouterLink,
    MatIconModule
  ],

  templateUrl: './account.html',
  styleUrl: './account.css'
})


export class Account implements OnInit {

  private holdTimer:
    ReturnType<typeof setTimeout> | null = null;

  private touchHoldActive = false;

  private activePointerId:
    number | null = null;


  userDetails:
    UserDetails | null = null;

  isUserDetailsLoading = true;

  userDetailsError = '';


  isCardFlipped = false;

  isCarouselAnimating = false;

  activeCardIndex = 0;


  cards = [
    {
      number:
        '4532 8912 7645 4821',

      holder:
        'OWL BANK USER',

      expiry:
        '08/29',

      cvv:
        '527'
    },

    {
      number:
        '5198 2241 6732 1147',

      holder:
        'OWL BANK USER',

      expiry:
        '11/29',

      cvv:
        '314'
    },

    {
      number:
        '4716 9034 2251 8890',

      holder:
        'OWL BANK USER',

      expiry:
        '03/30',

      cvv:
        '682'
    },

    {
      number:
        '5521 3309 8821 5412',

      holder:
        'OWL BANK USER',

      expiry:
        '07/30',

      cvv:
        '193'
    },

    {
      number:
        '4917 6432 1109 3748',

      holder:
        'OWL BANK USER',

      expiry:
        '12/30',

      cvv:
        '845'
    }
  ];


  constructor(
    private userService: UserService,
    private router: Router
  ) {}


  ngOnInit(): void {
    this.loadUserDetails();
  }


  loadUserDetails(): void {

    this.userDetailsError = '';

    this.userService
      .getUserDetails()
      .subscribe({

        next: (
          details: UserDetails
        ) => {

          this.userDetails =
            details;

          this.isUserDetailsLoading =
            false;
        },


        error: (
          error
        ) => {

          console.error(
            'User details request failed:',
            error
          );

          this.userDetailsError =
            'Could not load account details.';

          this.isUserDetailsLoading =
            false;
        }
      });
  }


  get activeCard() {
    return this.cards[
      this.activeCardIndex
    ];
  }


  get maskedCardNumber(): string {

    return (
      `.... .... .... ` +
      `${this.activeCard.number.slice(-4)}`
    );
  }


  getMaskedNumber(
    number: string
  ): string {

    return (
      `.... .... .... ` +
      `${number.slice(-4)}`
    );
  }


  selectCard(
    index: number
  ): void {

    if (
      this.isCarouselAnimating ||
      index ===
        this.activeCardIndex
    ) {
      return;
    }


    if (
      Math.abs(
        index -
        this.activeCardIndex
      ) !== 1
    ) {
      return;
    }


    this.isCarouselAnimating =
      true;


    this.isCardFlipped =
      false;


    this.activeCardIndex =
      index;


    setTimeout(() => {

      this.isCarouselAnimating =
        false;

    }, 560);
  }


  previous(): void {

    if (
      this.activeCardIndex > 0
    ) {

      this.selectCard(
        this.activeCardIndex - 1
      );
    }
  }


  next(): void {

    if (
      this.activeCardIndex <
      this.cards.length - 1
    ) {

      this.selectCard(
        this.activeCardIndex + 1
      );
    }
  }


  toggleCard(): void {

    if (
      this.isCarouselAnimating
    ) {
      return;
    }

    this.isCardFlipped =
      !this.isCardFlipped;
  }


  onCardPointerDown(
    event: PointerEvent,
    index: number
  ): void {

    if (
      index !==
        this.activeCardIndex ||
      this.isCarouselAnimating
    ) {
      return;
    }


    const wrapper =
      event.currentTarget;


    if (
      !(wrapper instanceof HTMLElement)
    ) {
      return;
    }


    if (
      event.pointerType ===
      'mouse'
    ) {

      this.triggerTurbulence(
        wrapper
      );

      return;
    }


    this.activePointerId =
      event.pointerId;


    this.touchHoldActive =
      false;


    wrapper.setPointerCapture(
      event.pointerId
    );


    this.holdTimer =
      setTimeout(() => {

        this.touchHoldActive =
          true;

        this.applyCardTilt(
          event,
          wrapper
        );

      }, 250);
  }


  onCardPointerMove(
    event: PointerEvent,
    index: number
  ): void {

    if (
      index !==
        this.activeCardIndex ||
      this.isCarouselAnimating
    ) {
      return;
    }


    const wrapper =
      event.currentTarget;


    if (
      !(wrapper instanceof HTMLElement)
    ) {
      return;
    }


    if (
      event.pointerType ===
      'mouse'
    ) {

      this.applyCardTilt(
        event,
        wrapper
      );

      return;
    }


    if (
      this.touchHoldActive &&
      event.pointerId ===
        this.activePointerId
    ) {

      this.applyCardTilt(
        event,
        wrapper
      );
    }
  }


  onCardPointerUp(
    event: PointerEvent,
    index: number
  ): void {

    if (
      index !==
      this.activeCardIndex
    ) {
      return;
    }


    const wrapper =
      event.currentTarget;


    if (
      !(wrapper instanceof HTMLElement)
    ) {
      return;
    }


    if (
      event.pointerType ===
      'mouse'
    ) {
      return;
    }


    if (
      this.holdTimer
    ) {

      clearTimeout(
        this.holdTimer
      );

      this.holdTimer =
        null;
    }


    if (
      !this.touchHoldActive
    ) {

      this.triggerTurbulence(
        wrapper
      );
    }


    this.resetCardTilt(
      wrapper
    );


    this.touchHoldActive =
      false;

    this.activePointerId =
      null;
  }


  onCardPointerLeave(
    event: PointerEvent
  ): void {

    const wrapper =
      event.currentTarget;


    if (
      !(wrapper instanceof HTMLElement)
    ) {
      return;
    }


    if (
      event.pointerType ===
      'mouse'
    ) {

      this.resetCardTilt(
        wrapper
      );
    }
  }


  onCardPointerCancel(
    event: PointerEvent
  ): void {

    const wrapper =
      event.currentTarget;


    if (
      !(wrapper instanceof HTMLElement)
    ) {
      return;
    }


    if (
      this.holdTimer
    ) {

      clearTimeout(
        this.holdTimer
      );

      this.holdTimer =
        null;
    }


    this.touchHoldActive =
      false;

    this.activePointerId =
      null;


    this.resetCardTilt(
      wrapper
    );
  }


  private applyCardTilt(
    event: PointerEvent,
    wrapper: HTMLElement
  ): void {

    const rect =
      wrapper
        .getBoundingClientRect();


    const mouseX =
      event.clientX -
      rect.left;


    const mouseY =
      event.clientY -
      rect.top;


    const centerX =
      rect.width / 2;


    const centerY =
      rect.height / 2;


    const rawX =
      (
        mouseX -
        centerX
      ) /
      centerX;


    const rawY =
      (
        mouseY -
        centerY
      ) /
      centerY;


    const distance =
      Math.sqrt(
        rawX * rawX +
        rawY * rawY
      );


    const deadZone =
      0.05;


    let rotateX =
      0;

    let rotateY =
      0;


    let lightAngle =
      135;

    let lightingOpacity =
      0;


    if (
      distance >
      deadZone
    ) {

      const directionX =
        rawX /
        distance;


      const directionY =
        rawY /
        distance;


      let strength =
        (
          Math.min(
            distance,
            1
          ) -
          deadZone
        ) /
        (
          1 -
          deadZone
        );


      strength =
        Math.max(
          0,
          Math.min(
            1,
            strength
          )
        );


      strength =
        Math.pow(
          strength,
          0.72
        );


      const maxTilt =
        11;


      rotateX =
        -directionY *
        maxTilt *
        strength;


      rotateY =
        directionX *
        maxTilt *
        strength;


      lightAngle =
        Math.atan2(
          -directionY,
          -directionX
        ) *
        180 /
        Math.PI +
        180;


      lightingOpacity =
        0.20 +
        strength *
        0.65;
    }


    wrapper.classList.add(
      'is-tilting'
    );


    wrapper.style.setProperty(
      '--tilt-x',
      `${rotateX}deg`
    );


    wrapper.style.setProperty(
      '--tilt-y',
      `${rotateY}deg`
    );


    wrapper.style.setProperty(
      '--light-angle',
      `${lightAngle}deg`
    );


    wrapper.style.setProperty(
      '--lighting-opacity',
      `${lightingOpacity}`
    );
  }


  private resetCardTilt(
    wrapper: HTMLElement
  ): void {

    wrapper.classList.remove(
      'is-tilting'
    );


    wrapper.style.setProperty(
      '--tilt-x',
      '0deg'
    );


    wrapper.style.setProperty(
      '--tilt-y',
      '0deg'
    );


    wrapper.style.setProperty(
      '--lighting-opacity',
      '0'
    );
  }


  private triggerTurbulence(
    wrapper: HTMLElement
  ): void {

    wrapper.classList.remove(
      'is-turbulent'
    );


    void wrapper.offsetWidth;


    wrapper.classList.add(
      'is-turbulent'
    );


    setTimeout(() => {

      wrapper.classList.remove(
        'is-turbulent'
      );

    }, 300);
  }

  isProfileMenuOpen = false;

toggleProfileMenu(): void {
  this.isProfileMenuOpen = !this.isProfileMenuOpen;
}

signOut(): void {
  localStorage.removeItem('token');

  this.isProfileMenuOpen = false;

  this.router.navigate(['/login']);
}
}